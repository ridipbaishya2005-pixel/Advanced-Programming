package com.score;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ScoreProcessor — File Handling Tests")
class ScoreProcessorTest {

    private ScoreProcessor processor;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        processor = new ScoreProcessor();
    }

    // -----------------------------------------------------------------------
    // Happy-path
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Valid file with integer 7 should return 70")
    void testValidFile_returnsScoreMultipliedByTen() throws IOException, FileNotFoundException {
        Path file = tempDir.resolve("score.txt");
        Files.writeString(file, "7");

        int result = processor.processScoreFile(file.toString());

        assertEquals(70, result);
    }

    @Test
    @DisplayName("Score 0 should return 0")
    void testZeroScore_returnsZero() throws IOException, FileNotFoundException {
        Path file = tempDir.resolve("zero.txt");
        Files.writeString(file, "0");

        assertEquals(0, processor.processScoreFile(file.toString()));
    }

    @Test
    @DisplayName("File with leading/trailing whitespace should still parse correctly")
    void testScoreWithWhitespace_parsesCorrectly() throws IOException, FileNotFoundException {
        Path file = tempDir.resolve("padded.txt");
        Files.writeString(file, "  42  ");

        assertEquals(420, processor.processScoreFile(file.toString()));
    }

    @Test
    @DisplayName("Negative score should be multiplied correctly")
    void testNegativeScore_returnsNegativeResult() throws IOException, FileNotFoundException {
        Path file = tempDir.resolve("negative.txt");
        Files.writeString(file, "-5");

        assertEquals(-50, processor.processScoreFile(file.toString()));
    }

    // -----------------------------------------------------------------------
    // Error-path: missing file
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("Non-existent file path should throw FileNotFoundException")
    void testMissingFile_throwsFileNotFoundException() {
        String missingPath = tempDir.resolve("does_not_exist.txt").toString();

        assertThrows(
            FileNotFoundException.class,
            () -> processor.processScoreFile(missingPath)
        );
    }

    // -----------------------------------------------------------------------
    // Error-path: bad file content
    // -----------------------------------------------------------------------

    @Test
    @DisplayName("File containing letters should throw NumberFormatException")
    void testCorruptedFile_throwsNumberFormatException() throws IOException {
        Path file = tempDir.resolve("corrupt.txt");
        Files.writeString(file, "abc");

        assertThrows(
            NumberFormatException.class,
            () -> processor.processScoreFile(file.toString())
        );
    }

    @Test
    @DisplayName("File containing a decimal number should throw NumberFormatException")
    void testDecimalScore_throwsNumberFormatException() throws IOException {
        Path file = tempDir.resolve("decimal.txt");
        Files.writeString(file, "3.14");

        assertThrows(
            NumberFormatException.class,
            () -> processor.processScoreFile(file.toString())
        );
    }
}
