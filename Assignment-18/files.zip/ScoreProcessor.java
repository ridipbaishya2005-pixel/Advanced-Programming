package com.score;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ScoreProcessor {

    /**
     * Reads an integer score from the given file, multiplies it by 10, and returns the result.
     *
     * @param filePath path to a text file containing a single integer
     * @return the score multiplied by 10
     * @throws FileNotFoundException if the file does not exist
     * @throws NumberFormatException if the file content cannot be parsed as an integer
     */
    public int processScoreFile(String filePath) throws FileNotFoundException, NumberFormatException {

        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(filePath));
            String line = reader.readLine();
            int score = Integer.parseInt(line.trim());
            return score * 10;

        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found at path '" + filePath + "'. " + e.getMessage());
            throw e;

        } catch (NumberFormatException e) {
            System.out.println("Error: File contains invalid data — expected an integer but got non-numeric content. " + e.getMessage());
            throw e;

        } catch (IOException e) {
            System.out.println("Error: Unexpected I/O problem while reading '" + filePath + "'. " + e.getMessage());
            throw new RuntimeException("Unexpected I/O error", e);

        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.out.println("Warning: Failed to close file reader. " + e.getMessage());
                }
            }
            System.out.println("File cleanup completed.");
        }
    }
}
